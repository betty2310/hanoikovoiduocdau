from hanoikovoidcdau.standardize import standardize_street_name


input = 'Phú Thưng'
print(standardize_street_name(input))
