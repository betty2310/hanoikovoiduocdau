Standardize Hanoi capital address

```py
street = "Dai La"
street = standardize_street_name(street) 

# street = "Đại La"

ward = "Bạch Đang"
ward = standardize_ward_name(ward)

# ward = "Bạch Đằng"

district = "Hai Ba Trung"
district = standardize_district_name(district)

# district = "Hai Bà Trưng"
```