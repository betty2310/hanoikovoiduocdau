```py
street = "Dai La"
street = standardize_street_name(street) 
# street = "Đại La"
```